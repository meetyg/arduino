#include "Logging.h"

void Logging::Init(int level, long baud){
    _level = constrain(level,LOG_LEVEL_NOOUTPUT,LOG_LEVEL_VERBOSE);
    _baud = baud;
    Serial.begin(_baud);
}

void Logging::Error(char* msg, ...){
    if (LOG_LEVEL_ERROR<= _level) {   
	print ("ERROR: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}

void Logging::Error(const __FlashStringHelper *msg, ...){
    if (LOG_LEVEL_ERROR<= _level) {   
	print ("ERROR: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}


void Logging::Warn(char* msg, ...){
    if (LOG_LEVEL_WARNING <= _level) {
	print ("WARNING: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}

void Logging::Warn(const __FlashStringHelper *msg, ...){
    if (LOG_LEVEL_WARNING <= _level) {
	print ("WARNING: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}

void Logging::Info(char* msg, ...){
    if (LOG_LEVEL_INFO <= _level) {
	print ("INFO: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}
void Logging::Info(const __FlashStringHelper *msg, ...){
    if (LOG_LEVEL_INFO <= _level) {
	print ("INFO: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}

void Logging::Debug(char* msg, ...){
    if (LOG_LEVEL_DEBUG <= _level) {
	print ("DEBUG: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}

void Logging::Debug(const __FlashStringHelper *msg, ...){
    if (LOG_LEVEL_DEBUG <= _level) {
	print ("DEBUG: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}

void Logging::Verbose(char* msg, ...){
    if (LOG_LEVEL_VERBOSE <= _level) {
	print ("VERBOSE: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}
void Logging::Verbose(const __FlashStringHelper *msg, ...){
    if (LOG_LEVEL_VERBOSE <= _level) {
	print ("VERBOSE: ",0);
        va_list args;
        va_start(args, msg);
        print(msg,args);
    }
}



 void Logging::print(const char *format, va_list args) {
    //
    // loop through format string
    for (; *format != 0; ++format) {
        if (*format == '%') {
            ++format;
            if (*format == '\0') break;
            if (*format == '%') {
                Serial.print(*format);
                continue;
            }
            if( *format == 's' ) {
				register char *s = (char *)va_arg( args, int );
				Serial.print(s);
				continue;
			}
            if( *format == 'd' || *format == 'i') {
				Serial.print(va_arg( args, int ),DEC);
				continue;
			}
            if( *format == 'f') {
				Serial.print(va_arg( args, double ),2);
				continue;
			}
            if( *format == 'x' ) {
				Serial.print(va_arg( args, int ),HEX);
				continue;
			}
            if( *format == 'X' ) {
				Serial.print("0x");
				Serial.print(va_arg( args, int ),HEX);
				continue;
			}
            if( *format == 'b' ) {
				Serial.print(va_arg( args, int ),BIN);
				continue;
			}
            if( *format == 'B' ) {
				Serial.print("0b");
				Serial.print(va_arg( args, int ),BIN);
				continue;
			}
            if( *format == 'l' ) {
				Serial.print(va_arg( args, long ),DEC);
				continue;
			}

            if( *format == 'c' ) {
				Serial.print(va_arg( args, int ));
				continue;
			}
            if( *format == 't' ) {
				if (va_arg( args, int ) == 1) {
					Serial.print("T");
				}
				else {
					Serial.print("F");				
				}
				continue;
			}
            if( *format == 'T' ) {
				if (va_arg( args, int ) == 1) {
					Serial.print("true");
				}
				else {
					Serial.print("false");				
				}
				continue;
			}

        }
	
       	Serial.print(*format);
    }
	if(args != NULL)
		Serial.println();
 }

void Logging::print(const __FlashStringHelper *ifsh, va_list args) {
  PGM_P p = reinterpret_cast<PGM_P>(ifsh);
  char chr;

  // loop through format string
  do 
  {
    chr = (char)pgm_read_byte(p++);

    if (chr == '%')
   {
       // read next:
        chr = (char)pgm_read_byte(p++);
 
	    switch (chr)
	    {
	      case '%':
	      {
	 	 Serial.print(chr);
		break;
	      }
	      case 's' :
	      {
	        register char *s = (char *)va_arg( args, int );
	        Serial.print(s);
	        break;
	      }
	      case 'd':
	      case 'i':
	      {
	        Serial.print(va_arg( args, int ),DEC);
	        break;
	      }
	      case 'f' :
	      {
	        Serial.print(va_arg( args, double ),2);
	        break;
	      }
	      case 'x' :
	      {
	        Serial.print(va_arg( args, int ),HEX);
	        break;
	      }
	      case 'X' : 
	      {
	        Serial.print("0x");
	        Serial.print(va_arg( args, int ),HEX);
	        break;
	      }
	      case 'b' :
	      {
	        Serial.print(va_arg( args, int ),BIN);
	        break;
	      }
	      case 'B' :
	      {
	        Serial.print("0b");
	        Serial.print(va_arg( args, int ),BIN);
	        break;
	      }
	      case 'l' :
	      {
	        Serial.print(va_arg( args, long ),DEC);
	        break;
	      }
	      case 'c' :
	      {
	        Serial.print(va_arg( args, int ));
	        break;
	      }
	      case 't' :
	      {
	        if (va_arg( args, int ) == 1) 
	          Serial.print("T");
	        else
	          Serial.print("F");        
	
	        break;      
	      }
	      case 'T' :
	      {
	        if (va_arg( args, int ) == 1)
	          Serial.print("true");
	        else
	          Serial.print("false");        
	        
	        break;
	      }
	      default:
	      {
	        Serial.print(chr);
	        break;
	      }
	    }
	}
	else
		 Serial.print(chr);
  } while (chr != NULL);
   
        
  if(args != NULL)
    Serial.println();
 }
 
 Logging Log = Logging();

 
 
  




