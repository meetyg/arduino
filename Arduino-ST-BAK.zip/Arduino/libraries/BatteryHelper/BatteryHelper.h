#ifndef BATTERYHELPER_H
#define BATTERYHELPER_H

#include "Arduino.h"

enum BatteryLevelStatus
{
    OK,
    Low,
    Critical
};

class BatteryHelper {
private:
    int numVoltageReadsPerSec;
    float lowLevel, criticalLevel;

    long readVccMv();

public:
    float getBatteryLevel();
    BatteryLevelStatus getBatteryLevelStatus(float& outLevel);
    
    BatteryHelper(float low, float critical, int numReadsPerSec)
    {
        lowLevel = low;
        criticalLevel = critical;
        numVoltageReadsPerSec = numReadsPerSec;
    };
};

#endif
