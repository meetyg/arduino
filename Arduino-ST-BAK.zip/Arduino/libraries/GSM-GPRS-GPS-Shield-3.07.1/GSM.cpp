
#include "GSM.h"
#include "WideTextFinder.h"

#define _GSM_TXPIN_ 7
#define _GSM_RXPIN_ 8  


#ifdef UNO
GSM::GSM():_cell(_GSM_TXPIN_,_GSM_RXPIN_),_tf(_cell, 10),_status(IDLE){
   // Set pin modes
   pinMode(GSM_ON,OUTPUT);
   pinMode(GSM_RESET,OUTPUT);
};
#endif
#ifdef MEGA
GSM::GSM(){
   // Set pin modes
   pinMode(GSM_ON,OUTPUT);
   pinMode(GSM_RESET,OUTPUT);

  _cell.begin(9600);
};
#endif

void GSM::powerOn()
{
   digitalWrite(GSM_ON,LOW);
   delay(100);
   digitalWrite(GSM_ON,HIGH);
   delay(2000);
   digitalWrite(GSM_ON,LOW);
   delay(100);
}

void GSM::powerOff()
{
	// Try "soft" power down first:
	if( AT_RESP_OK ==
		SendATCmdWaitResp(F("AT+CPOWD=1"), 500, 100, "NORMAL POWER DOWN", 5))
	{
		return;
	}
	
	// "Hard" power down
	digitalWrite(GSM_ON,LOW);
	 delay(100);
	 digitalWrite(GSM_ON,HIGH);
	 delay(2000);
	 digitalWrite(GSM_ON,LOW);
	 delay(100);
}

void GSM::end()
{
 	for(int retryCount = 0; (retryCount < 3) ; retryCount++)
 	{
		// Check for power:
	 	if( AT_RESP_ERR_NO_RESP != SendATCmdWaitResp(str_at, 500, 100, str_ok, 5))
		{
			// Power is On, try to powerOff:
			powerOff();
		}
		else
		{
			// Power is Off, stop loop:
			 setStatus(IDLE); 
			return;
		}
		delay(100);
	} 
}
int GSM::begin(long baud_rate){
  
  #ifdef UNO
    if (baud_rate==115200){
      Serial.println("Don't use baudrate 115200 with Software Serial.\nAutomatically changed at 9600.");
      baud_rate=9600;
    }
  #endif
  
  at_resp_enum  response=AT_RESP_ERR_NO_RESP;
  int baud_rates[] = { 1200, 2400, 4800, 9600, 19200, 38400, 57600,74880, 115200  }; 
  int arrlen = sizeof(baud_rates)/sizeof(baud_rates[0]);  
  boolean noReply=true;
  boolean turnedOn=false;

  SetCommLineStatus(CLS_ATCMD);
  
  _cell.begin(baud_rate);
  p_comm_buf = &comm_buf[0];
  setStatus(IDLE); 

  for(int retryCount = 0; (retryCount < 3) && noReply; retryCount++)
  {
    // Check if power is ON by sending AT command and waiting for response:
    response = SendATCmdWaitResp(str_at, 1000, 500, str_ok, 5);
  
    #ifdef DEBUG_ON
        String strResp = "DBG: Response (" + String(retryCount +1) + "/3): " + String(response);
        Serial.println(strResp);    
    #endif
    switch (response)
    {
      // No response received, GSM is probably OFF.
      case AT_RESP_ERR_NO_RESP:
        if(!turnedOn)
        {
          // Try to turn GSM ON
          powerOn();  
        } 
        // Wait for any response, will clear RX buffers.
        WaitResp(1000, 1000);   
      break; // continue to retries

      // Response received but its invalid or not as expected.
      // Current GSM baud-rate may not be as requested.
      case AT_RESP_ERR_DIF_RESP:
        #ifdef DEBUG_ON
          Serial.println("DBG: AT_RESP_ERR_DIF_RESP");    
        #endif

        turnedOn = true;

        // Wait for any response, will clear RX buffers.
        WaitResp(1000, 1000);   

        // Try to find current GSM baud-rate
        for(int i=0; i < arrlen; i++)
        {
          #ifdef DEBUG_ON
            Serial.print("DBG: Trying to connect with baud-rate: ");
            Serial.println(baud_rates[i]);    
          #endif

          // Try to connect with other baud-rate
          _cell.begin(baud_rates[i]);
          delay(100);
          
          // Check communication after temp baud-rate change:
          if (AT_RESP_OK == SendATCmdWaitResp(str_at, 500, 100,str_ok, 5)) 
          {
            #ifdef DEBUG_ON
              Serial.print("DBG: Success connecting with temp baud-rate: ");
              Serial.println(baud_rates[i]);    
              Serial.print("DBG: Setting requested baud-rate: ");
              Serial.println(baud_rate);
            #endif

            // set GSM baud-rate to requested baud-rate
            _cell.print(F("AT+IPR="));
            _cell.println(baud_rate);            
            delay(500);
            // Reconnect with requested baud-rate
            _cell.begin(baud_rate);
            delay(200);
            // Reset the GSM module so that new baud-rate will work   
            SendATCmdWaitResp("AT+CFUN=1,1", 500, 100,str_ok, 5);
            delay(200);
            WaitResp(1000, 1000);   
            // Make sure we have at least another retry so that 
            // a valid connection can be made.
            retryCount--;
            break;  // stop looking for temp baud-rate
          }
        }
        break; // new baud-rate set, continue to retries
        
        case AT_RESP_OK:
          turnedOn = true;
          noReply = false;
        break;
      } // switch
  } // end for reties

  // communication line is not used yet = free
  SetCommLineStatus(CLS_FREE);
  // pointer is initialized to the first item of comm. buffer
  p_comm_buf = &comm_buf[0];

  if(turnedOn)
  {
    if(!noReply)
    {
      WaitResp(50, 50);
      InitParam(PARAM_SET_0);
      InitParam(PARAM_SET_1);//configure the module
      #ifdef DEBUG_ON
        Echo(1);               // enable AT echo
      #else  
        Echo(0);               // disable AT echo
      #endif  
      setStatus(READY);
      return(1);
    }
  }

  Serial.println(F("ERROR: SIM900 doesn't answer. Check power and serial pins in GSM.cpp"));
  return 0;
}

void GSM::InitParam(byte group){
  switch (group) {
  case PARAM_SET_0:
    // check comm line
    //if (CLS_FREE != GetCommLineStatus()) return;

    SetCommLineStatus(CLS_ATCMD);
    // Reset to the factory settings
    SendATCmdWaitResp("AT&F", 1000, 100, "OK", 5);      
    // Get Time from network:
    SendATCmdWaitResp("AT+CLTS=1", 1000, 100, "OK", 5);
    // Set character set:
    SendATCmdWaitResp("AT+CSCS=\"GSM\"", 500, 100, "OK", 5);
    SetCommLineStatus(CLS_FREE);
    break;

  case PARAM_SET_1:
    // check comm line
    //if (CLS_FREE != GetCommLineStatus()) return;
    SetCommLineStatus(CLS_ATCMD);
    // Request calling line identification
    SendATCmdWaitResp(F("AT+CLIP=1"), 500, 100, "OK", 5);
    // Mobile Equipment Error Code
    SendATCmdWaitResp(F("AT+CMEE=0"), 500, 100, "OK", 5);
    // set the SMS mode to text 
    SendATCmdWaitResp(F("AT+CMGF=1"), 500, 100, "OK", 5);
    // init SMS storage
    InitSMSMemory();
    // select phonebook memory storage
    SendATCmdWaitResp(F("AT+CPBS=\"SM\""), 500, 100, "OK", 5);
    SendATCmdWaitResp(F("AT+CIPSHUT"), 500, 100, "SHUT OK", 5);
    SetCommLineStatus(CLS_FREE);

    break;
  }
}

byte GSM::WaitResp(uint16_t start_comm_tmout, uint16_t max_interchar_tmout, 
                   char const *expected_resp_string)
{
  byte status;
  byte ret_val;

  RxInit(start_comm_tmout, max_interchar_tmout); 
  // wait until response is not finished
  do {
    status = IsRxFinished();
  } while (status == RX_NOT_FINISHED);

  if (status == RX_FINISHED) {
    // something was received but what was received?
    // ---------------------------------------------
  
    if(IsStringReceived(expected_resp_string)) {
      // expected string was received
      // ----------------------------
      ret_val = RX_FINISHED_STR_RECV;      
    }
    else {
  ret_val = RX_FINISHED_STR_NOT_RECV;
  }
  }
  else {
    // nothing was received
    // --------------------
    ret_val = RX_TMOUT_ERR;
  }
  return (ret_val);
}


/**********************************************************
Method sends AT command and waits for response

return: 
      AT_RESP_ERR_NO_RESP = -1,   // no response received
      AT_RESP_ERR_DIF_RESP = 0,   // response_string is different from the response
      AT_RESP_OK = 1,             // response_string was included in the response
**********************************************************/
 at_resp_enum  GSM::SendATCmdWaitResp(char const *AT_cmd_string,
                uint16_t start_comm_tmout, uint16_t max_interchar_tmout,
                char const *response_string,
                byte no_of_attempts)
{
  byte status;
   at_resp_enum ret_val = AT_RESP_ERR_NO_RESP;
  byte i;

  for (i = 0; i < no_of_attempts; i++) {
    // delay 500 msec. before sending next repeated AT command 
    // so if we have no_of_attempts=1 tmout will not occurred
    if (i > 0) delay(500); 

    _cell.println(AT_cmd_string);
    status = WaitResp(start_comm_tmout, max_interchar_tmout); 
    if (status == RX_FINISHED) {
      // something was received but what was received?
      // ---------------------------------------------
      if(IsStringReceived(response_string)) {
        ret_val = AT_RESP_OK;      
        break;  // response is OK => finish
      }
      else ret_val = AT_RESP_ERR_DIF_RESP;
    }
    else {
      // nothing was received
      // --------------------
      ret_val = AT_RESP_ERR_NO_RESP;
    }
    
  }

 // WaitResp(1000, 5000); 
  return (ret_val);
}


/**********************************************************
Method sends AT command and waits for response

return: 
      AT_RESP_ERR_NO_RESP = -1,   // no response received
      AT_RESP_ERR_DIF_RESP = 0,   // response_string is different from the response
      AT_RESP_OK = 1,             // response_string was included in the response
**********************************************************/
 at_resp_enum GSM::SendATCmdWaitResp(const __FlashStringHelper *AT_cmd_string,
                uint16_t start_comm_tmout, uint16_t max_interchar_tmout,
                char const *response_string,
                byte no_of_attempts)
{
  byte status;
   at_resp_enum ret_val = AT_RESP_ERR_NO_RESP;
  byte i;

  for (i = 0; i < no_of_attempts; i++) {
    // delay 500 msec. before sending next repeated AT command 
    // so if we have no_of_attempts=1 tmout will not occurred
    if (i > 0) delay(500); 

    _cell.println(AT_cmd_string);
    status = WaitResp(start_comm_tmout, max_interchar_tmout); 
    if (status == RX_FINISHED) {
      // something was received but what was received?
      // ---------------------------------------------
      if(IsStringReceived(response_string)) {
        ret_val = AT_RESP_OK;      
        break;  // response is OK => finish
      }
      else ret_val = AT_RESP_ERR_DIF_RESP;
    }
    else {
      // nothing was received
      // --------------------
      ret_val = AT_RESP_ERR_NO_RESP;
    }
    
  }

  return (ret_val);
}

byte GSM::WaitResp(uint16_t start_comm_tmout, uint16_t max_interchar_tmout)
{
  byte status;

  RxInit(start_comm_tmout, max_interchar_tmout); 
  // wait until response is not finished
  do {
    status = IsRxFinished();
  } while (status == RX_NOT_FINISHED);
  return (status);
}

byte GSM::IsRxFinished(void)
{
  byte num_of_bytes;
  byte ret_val = RX_NOT_FINISHED;  // default not finished

  // Rx state machine
  // ----------------

  if (rx_state == RX_NOT_STARTED) {
    // Reception is not started yet - check tmout
    if (!_cell.available()) {
      // still no character received => check timeout
  /*  
  #ifdef DEBUG_GSMRX
    
      DebugPrint("\r\nDEBUG: reception timeout", 0);      
      Serial.print((unsigned long)(millis() - prev_time));  
      DebugPrint("\r\nDEBUG: start_reception_tmout\r\n", 0);      
      Serial.print(start_reception_tmout);  
      
    
  #endif
  */
      if ((unsigned long)(millis() - prev_time) >= start_reception_tmout) {
        // timeout elapsed => GSM module didn't start with response
        // so communication is takes as finished
    /*
      #ifdef DEBUG_GSMRX    
        DebugPrint("\r\nDEBUG: RECEPTION TIMEOUT", 0);  
      #endif
    */
        comm_buf[comm_buf_len] = 0x00;
        ret_val = RX_TMOUT_ERR;
      }
    }
    else {
      // at least one character received => so init inter-character 
      // counting process again and go to the next state
      prev_time = millis(); // init tmout for inter-character space
      rx_state = RX_ALREADY_STARTED;
    }
  }

  if (rx_state == RX_ALREADY_STARTED) {
    // Reception already started
    // check new received bytes
    // only in case we have place in the buffer
    num_of_bytes = _cell.available();
    // if there are some received bytes postpone the timeout
    if (num_of_bytes) prev_time = millis();
      
    // read all received bytes      
    while (num_of_bytes) {
      num_of_bytes--;
      if (comm_buf_len < COMM_BUF_LEN) {
        // we have still place in the GSM internal comm. buffer =>
        // move available bytes from circular buffer 
        // to the rx buffer
        *p_comm_buf = _cell.read();

        p_comm_buf++;
        comm_buf_len++;
        comm_buf[comm_buf_len] = 0x00;  // and finish currently received characters
                                        // so after each character we have
                                        // valid string finished by the 0x00
      }
      else {
        // comm buffer is full, other incoming characters
        // will be discarded 
        // but despite of we have no place for other characters 
        // we still must to wait until  
        // inter-character tmout is reached
        
        // so just readout character from circular RS232 buffer 
        // to find out when communication id finished(no more characters
        // are received in inter-char timeout)
        _cell.read();
      }
    }

    // finally check the inter-character timeout 
  /*
  #ifdef DEBUG_GSMRX
    
      DebugPrint("\r\nDEBUG: intercharacter", 0);     
<     Serial.print((unsigned long)(millis() - prev_time));  
      DebugPrint("\r\nDEBUG: interchar_tmout\r\n", 0);      
      Serial.print(interchar_tmout);  
      
    
  #endif
  */
    if ((unsigned long)(millis() - prev_time) >= interchar_tmout) {
      // timeout between received character was reached
      // reception is finished
      // ---------------------------------------------
    
    /*
      #ifdef DEBUG_GSMRX
    
      DebugPrint("\r\nDEBUG: OVER INTER TIMEOUT", 0);         
    #endif
    */
      comm_buf[comm_buf_len] = 0x00;  // for sure finish string again
                                      // but it is not necessary
      ret_val = RX_FINISHED;
    }
  }
    
  
  return (ret_val);
}

/**********************************************************
Method checks received bytes

compare_string - pointer to the string which should be find

return: 0 - string was NOT received
        1 - string was received
**********************************************************/
byte GSM::IsStringReceived(char const *compare_string)
{
  char *ch;
  byte ret_val = 0;

  if(comm_buf_len) {
  /*
    #ifdef DEBUG_GSMRX
      DebugPrint("DEBUG: Compare the string: \r\n", 0);
      for (int i=0; i<comm_buf_len; i++){
        Serial.print(byte(comm_buf[i]));  
      }
      
      DebugPrint("\r\nDEBUG: with the string: \r\n", 0);
      Serial.print(compare_string); 
      DebugPrint("\r\n", 0);
    #endif
  */
  #ifdef DEBUG_ON
    Serial.print("ATT: ");
    Serial.println(compare_string);
    Serial.print("RIC: ");
    Serial.println((char *)comm_buf);
  #endif
    ch = strstr((char *)comm_buf, compare_string);
    if (ch != NULL) {
      ret_val = 1;
    /*#ifdef DEBUG_PRINT
    DebugPrint("\r\nDEBUG: expected string was received\r\n", 0);
    #endif
    */
    }
  else
  {
    
    /*#ifdef DEBUG_PRINT
    DebugPrint("\r\nDEBUG: expected string was NOT received\r\n", 0);
    #endif
    */
  }
  }
  else{
  #ifdef DEBUG_ON
    Serial.print("ATT: ");
    Serial.println(compare_string);
    Serial.print("RIC: NO STRING RCVD");
  #endif
  }

  return (ret_val);
}


void GSM::RxInit(uint16_t start_comm_tmout, uint16_t max_interchar_tmout)
{
  rx_state = RX_NOT_STARTED;
  start_reception_tmout = start_comm_tmout;
  interchar_tmout = max_interchar_tmout;
  prev_time = millis();
  comm_buf[0] = 0x00; // end of string
  p_comm_buf = &comm_buf[0];
  comm_buf_len = 0;
  _cell.flush(); // erase rx circular buffer
}

void GSM::Echo(byte state)
{
  if (state == 0 or state == 1)
  {
    SetCommLineStatus(CLS_ATCMD);

    _cell.print("ATE");
    _cell.print((int)state);    
    _cell.print("\r");
    delay(500);
    SetCommLineStatus(CLS_FREE);
  }
}

char GSM::InitSMSMemory(void) 
{
  char ret_val = -1;

  if (CLS_FREE != GetCommLineStatus()) return (ret_val);
  SetCommLineStatus(CLS_ATCMD);
  ret_val = 0; // not initialized yet
  
  // Disable messages about new SMS from the GSM module 
  SendATCmdWaitResp("AT+CNMI=2,0", 1000, 100, "OK", 2);

  // send AT command to init memory for SMS in the SIM card
  // response:
  // +CPMS: <usedr>,<totalr>,<usedw>,<totalw>,<useds>,<totals>
  if (AT_RESP_OK == SendATCmdWaitResp("AT+CPMS=\"SM\",\"SM\",\"SM\"", 1000, 1000, "+CPMS:", 10)) {
    ret_val = 1;
  }
  else ret_val = 0;

  SetCommLineStatus(CLS_FREE);
  return (ret_val);
}

int GSM::isIP(const char* cadena)
{
    int i;
    for (i=0; i<strlen(cadena); i++)
        if (!(cadena[i]=='.' || ( cadena[i]>=48 && cadena[i] <=57)))
            return 0;
    return 1;
}

int GSM::getSignalQuality()
{
	int result = 0;
	SetCommLineStatus(CLS_ATCMD);
  
	// AT+CSQ
	if (AT_RESP_OK == SendATCmdWaitResp("AT+CSQ", 1000, 500, "OK", 5)) 
	{
		if(comm_buf_len > 0)
		{		
			String commResult((char*)comm_buf);
			commResult = commResult.substring(commResult.indexOf(" ")+1, commResult.indexOf(","));
			int tempRes = commResult.toInt();
			if(tempRes != 99) // 99 = unknown
			{
				result = map(tempRes,0,31,0,100);
			}
		}
	}
	SetCommLineStatus(CLS_FREE);
	return result;	
}

String GSM::getDateTimeString()
{
  String result;
  SetCommLineStatus(CLS_ATCMD);
  
  // AT+CCLK?
  if (AT_RESP_OK == SendATCmdWaitResp("AT+CCLK?", 1000, 500, "OK", 5)) 
  {
	if(comm_buf_len > 0)
	{
		String day,month,year("20"),hours,minutes,seconds;
		String commResult((char*)comm_buf);
		commResult = commResult.substring(commResult.indexOf("\"")+1, commResult.lastIndexOf("\""));
		// response format "16/01/02,20:46:33+08"
		const char delims[] = "/,:+";
		
		 char * pch;	
		int index=0;
		  pch = strtok ((char*)commResult.c_str(),delims);

		  if (pch != NULL)
			year.concat(pch);
		  pch = strtok (NULL,delims);

		  if (pch != NULL)
			month = pch;
		  pch = strtok (NULL,delims);
		
		  if (pch != NULL)
			day = pch;
		  pch = strtok (NULL,delims);

		  if (pch != NULL)
			hours = pch;
		  pch = strtok (NULL,delims);

		  if (pch != NULL)
			minutes = pch;
		  pch = strtok (NULL,delims);

		  if (pch != NULL)
			seconds = pch;
		  pch = strtok (NULL,delims);

		result.concat(day + "/" + month + "/" + year + " " + hours + ":" + minutes + ":" + seconds );
	}
  }
  SetCommLineStatus(CLS_FREE);
	return result;
}





