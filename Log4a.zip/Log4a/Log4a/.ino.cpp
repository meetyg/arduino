//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2016-02-05 15:51:00

#include "Arduino.h"
#include "Log4aMacroOpt.h"
void setup() ;
void loop() ;

#include "Log4a.ino"

